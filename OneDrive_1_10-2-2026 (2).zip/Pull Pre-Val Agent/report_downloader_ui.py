"""
Pre-Valuation Report Downloader
=================================
Select funds and month-end dates, then click Run to pull
pre-valuation PDFs from the Hermes portal via Microsoft Edge.
"""

import tkinter as tk
from tkinter import ttk, messagebox
import asyncio
import threading
import os
from datetime import datetime, date
from playwright.async_api import async_playwright, TimeoutError as PlaywrightTimeout

try:
    import openpyxl
    OPENPYXL_AVAILABLE = True
except ImportError:
    OPENPYXL_AVAILABLE = False

# ── Colours / fonts (matching the Investor Activity Review screen) ─────
NAVY  = "#1B2A4A"
WHITE = "#FFFFFF"
BG    = "#F5F5F5"
FONT  = "Calibri"
MONO  = "Consolas"

# ── Configuration ──────────────────────────────────────────────────────
MAPPING_FILE = (
    r"C:\Users\PMANN\OneDrive - GCM Grosvenor\Desktop\Claude"
    r"\Month End Packet Review - Investor Activity"
    r"\Mapping File\Investor Activity - Mapping File.xlsx"
)
MAPPING_SHEET = "Investor Activity Mapping"

HERMES_FUNDS_FILE = (
    r"C:\Users\PMANN\OneDrive - GCM Grosvenor\Desktop\Claude"
    r"\Month End Packet Review - pull pre-val"
    r"\Hermes Funds\FOF Allocation - 8.4.2026.xlsx"
)

SAVE_FOLDER = (
    r"C:\Users\PMANN\OneDrive - GCM Grosvenor\ARS Fund Accounting Team - Claude Preval Packet Prep"
    r"\Pull Pre-Val Agent\Output"
)

DATES = [
    ("December 31, 2025",  "12/31/2025"),
    ("January 31, 2026",   "01/31/2026"),
    ("February 28, 2026",  "02/28/2026"),
    ("March 31, 2026",     "03/31/2026"),
    ("April 30, 2026",     "04/30/2026"),
    ("May 31, 2026",       "05/31/2026"),
    ("June 30, 2026",      "06/30/2026"),
    ("July 31, 2026",      "07/31/2026"),
    ("August 31, 2026",    "08/31/2026"),
    ("September 30, 2026", "09/30/2026"),
    ("October 31, 2026",   "10/31/2026"),
    ("November 30, 2026",  "11/30/2026"),
    ("December 31, 2026",  "12/31/2026"),
]


# ── Helpers ────────────────────────────────────────────────────────────

def load_funds_from_excel():
    if not OPENPYXL_AVAILABLE:
        return ["openpyxl not installed — run:  pip install openpyxl"]
    try:
        wb    = openpyxl.load_workbook(MAPPING_FILE, read_only=True, data_only=True)
        ws    = wb[MAPPING_SHEET]
        funds = []
        for row in ws.iter_rows(min_row=2, min_col=1, max_col=1, values_only=True):
            v = row[0]
            if v and isinstance(v, str) and v.strip():
                funds.append(v.strip())
        wb.close()
        return sorted(set(funds))
    except Exception as exc:
        return [f"Error reading mapping file: {exc}"]


def load_hermes_funds():
    """Return a set of fund names where Team = 'Hermes' in the FOF Allocation file."""
    if not OPENPYXL_AVAILABLE:
        return set()
    import shutil, tempfile, os as _os
    try:
        tmp = tempfile.mktemp(suffix=".xlsx")
        shutil.copy2(HERMES_FUNDS_FILE, tmp)
        wb  = openpyxl.load_workbook(tmp, read_only=True, data_only=True)
        ws  = wb.active
        funds = set()
        for row in ws.iter_rows(min_row=2, min_col=1, max_col=2, values_only=True):
            fund, team = row
            if team == "Hermes" and fund and isinstance(fund, str):
                funds.add(fund.strip())
        wb.close()
        _os.remove(tmp)
        return funds
    except Exception:
        return set()


def fmt_filename_date(date_str):
    """12/31/2025  ->  12.31.2025"""
    return datetime.strptime(date_str, "%m/%d/%Y").strftime("%m.%d.%Y")


# ── Scrollable frame ───────────────────────────────────────────────────

class ScrollableFrame(tk.Frame):
    def __init__(self, parent, bg=BG, **kw):
        super().__init__(parent, bg=bg, **kw)
        self.canvas    = tk.Canvas(self, highlightthickness=0, bg=bg)
        self.scrollbar = ttk.Scrollbar(self, orient="vertical",
                                        command=self.canvas.yview)
        self.inner     = tk.Frame(self.canvas, bg=bg)
        self.inner.bind("<Configure>",
            lambda _: self.canvas.configure(
                scrollregion=self.canvas.bbox("all")))
        self.canvas.create_window((0, 0), window=self.inner, anchor="nw")
        self.canvas.configure(yscrollcommand=self.scrollbar.set)
        self.canvas.pack(side="left", fill="both", expand=True)
        self.scrollbar.pack(side="right", fill="y")
        for w in (self.canvas, self.inner):
            w.bind("<MouseWheel>", self._scroll)

    def _scroll(self, e):
        self.canvas.yview_scroll(int(-1 * (e.delta / 120)), "units")

    def hook(self, w):
        """Attach mouse-wheel scrolling to a child widget."""
        w.bind("<MouseWheel>", self._scroll)


# ══════════════════════════════════════════════════════════════════════
#   Main application
# ══════════════════════════════════════════════════════════════════════

class App(tk.Tk):

    def __init__(self):
        super().__init__()
        self.title("Pre-Valuation Report Downloader")
        self.configure(bg=BG)
        self.resizable(True, True)
        self.minsize(820, 620)

        self.fund_vars  = {}        # fund name  -> BooleanVar
        self.date_vars  = {}        # date value -> BooleanVar
        self._fund_rows = []        # (name, frame, var) for filtering

        self._build_ui()
        self._center()
        self._load_funds()

    # ── Layout ────────────────────────────────────────────────────────

    def _center(self):
        self.update_idletasks()
        w, h = 900, 680
        x = (self.winfo_screenwidth()  - w) // 2
        y = (self.winfo_screenheight() - h) // 2
        self.geometry(f"{w}x{h}+{x}+{y}")

    def _build_ui(self):

        # ── Header bar ────────────────────────────────────────────────
        header = tk.Frame(self, bg=NAVY, pady=12)
        header.pack(fill="x")
        tk.Label(header,
                 text="GCM Grosvenor \u2014 Pre-Valuation Report Downloader",
                 bg=NAVY, fg=WHITE,
                 font=(FONT, 13, "bold")).pack(padx=16, anchor="w")

        # ── Controls row ──────────────────────────────────────────────
        ctrl = tk.Frame(self, bg=BG, padx=16, pady=10)
        ctrl.pack(fill="x")

        # Run button
        self.run_btn = tk.Button(
            ctrl, text="\u25b6  Run Reports",
            command=self._start_run,
            bg=NAVY, fg=WHITE, activebackground="#2e4a7a",
            font=(FONT, 11, "bold"),
            relief="flat", padx=16, pady=5, cursor="hand2"
        )
        self.run_btn.pack(side="left", padx=(0, 12))

        # Open folder button
        self.folder_btn = tk.Button(
            ctrl, text="\U0001f4c2  Open Save Folder",
            command=lambda: os.startfile(SAVE_FOLDER),
            bg="#D9D9D9", fg="#333",
            font=(FONT, 11),
            relief="flat", padx=12, pady=5, cursor="hand2"
        )
        self.folder_btn.pack(side="left")

        # Summary label (shows selected count when items are chosen)
        self.summary_var = tk.StringVar(value="Select funds and dates below, then click Run.")
        tk.Label(ctrl, textvariable=self.summary_var,
                 bg=BG, fg="#555", font=(FONT, 9),
                 justify="left").pack(side="left", padx=(16, 0))

        # ── Two-column selection area ──────────────────────────────────
        sel = tk.Frame(self, bg=BG, padx=16, pady=4)
        sel.pack(fill="both", expand=True)
        sel.columnconfigure(0, weight=3)   # funds column wider
        sel.columnconfigure(1, weight=1)
        sel.rowconfigure(0, weight=1)

        # Left — Funds
        fund_lf = tk.LabelFrame(sel, text="  Select Funds  ",
                                  bg=BG, fg=NAVY,
                                  font=(FONT, 10, "bold"),
                                  relief="groove", bd=1)
        fund_lf.grid(row=0, column=0, sticky="nsew", padx=(0, 8))
        fund_lf.rowconfigure(2, weight=1)
        fund_lf.columnconfigure(0, weight=1)

        # Search
        search_fr = tk.Frame(fund_lf, bg=BG)
        search_fr.grid(row=0, column=0, sticky="ew", padx=8, pady=(8, 4))
        tk.Label(search_fr, text="Search:", bg=BG,
                 font=(FONT, 10)).pack(side="left")
        self.search_var = tk.StringVar()
        self.search_var.trace("w", lambda *_: self._filter_funds())
        tk.Entry(search_fr, textvariable=self.search_var,
                 font=(FONT, 10), relief="solid", bd=1).pack(
                     side="left", fill="x", expand=True, padx=(6, 0))

        # All / None / Hermes Only buttons + count label
        btn_fr = tk.Frame(fund_lf, bg=BG)
        btn_fr.grid(row=1, column=0, sticky="ew", padx=8, pady=(0, 4))
        for label, state in [("Select All", True), ("Select None", False)]:
            s = state   # capture for lambda
            tk.Button(btn_fr, text=label, width=10,
                      bg="#D9D9D9", relief="flat", font=(FONT, 9),
                      command=lambda st=s: self._toggle_visible_funds(st)
                      ).pack(side="left", padx=(0, 4))
        tk.Button(btn_fr, text="Hermes Only", width=11,
                  bg=NAVY, fg=WHITE, relief="flat", font=(FONT, 9),
                  command=self._select_hermes_funds
                  ).pack(side="left", padx=(0, 4))
        self.fund_count_lbl = tk.Label(btn_fr, text="", bg=BG,
                                        fg="#666", font=(FONT, 9))
        self.fund_count_lbl.pack(side="right")

        # Scrollable fund list
        self.fund_scroll = ScrollableFrame(fund_lf, bg=BG)
        self.fund_scroll.grid(row=2, column=0, sticky="nsew", padx=6, pady=(0, 6))

        # Right — Dates
        date_lf = tk.LabelFrame(sel, text="  Select Dates  ",
                                  bg=BG, fg=NAVY,
                                  font=(FONT, 10, "bold"),
                                  relief="groove", bd=1)
        date_lf.grid(row=0, column=1, sticky="nsew")

        btn_fr2 = tk.Frame(date_lf, bg=BG)
        btn_fr2.pack(fill="x", padx=8, pady=(8, 4))
        for label, state in [("All", True), ("None", False)]:
            s = state
            tk.Button(btn_fr2, text=label, width=6,
                      bg="#D9D9D9", relief="flat", font=(FONT, 9),
                      command=lambda st=s: self._toggle_all(self.date_vars, st)
                      ).pack(side="left", padx=(0, 4))

        for display, value in DATES:
            var = tk.BooleanVar(value=False)
            self.date_vars[value] = var
            cb = tk.Checkbutton(date_lf, text=display, variable=var,
                                 bg=BG, anchor="w",
                                 font=(FONT, 10),
                                 command=self._refresh_summary)
            cb.pack(fill="x", padx=10, pady=1)

        # ── Output (dark terminal) ─────────────────────────────────────
        out_fr = tk.Frame(self, bg=BG, padx=16, pady=6)
        out_fr.pack(fill="both", expand=False)
        tk.Label(out_fr, text="Output:", bg=BG, fg=NAVY,
                 font=(FONT, 10, "bold")).pack(anchor="w", pady=(0, 4))

        txt_wrap = tk.Frame(out_fr)
        txt_wrap.pack(fill="both", expand=True)

        self.output = tk.Text(
            txt_wrap, wrap="word",
            bg="#1e1e1e", fg="#d4d4d4",
            font=(MONO, 9), relief="flat",
            state="disabled", padx=8, pady=8,
            height=10
        )
        sb = ttk.Scrollbar(txt_wrap, command=self.output.yview)
        self.output.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        self.output.pack(side="left", fill="both", expand=True)

        self.output.tag_configure("ok",    foreground="#4ec9b0")
        self.output.tag_configure("warn",  foreground="#ce9178")
        self.output.tag_configure("error", foreground="#f44747")
        self.output.tag_configure("head",  foreground="#569cd6",
                                   font=(MONO, 9, "bold"))

        # ── Status bar ────────────────────────────────────────────────
        self.status_var = tk.StringVar(
            value="Ready. Select funds and dates, then click Run.")
        tk.Label(self, textvariable=self.status_var,
                 bg=NAVY, fg=WHITE, font=(FONT, 9),
                 anchor="w", padx=10).pack(fill="x", side="bottom")

    # ── Populate fund list ─────────────────────────────────────────────

    def _load_funds(self):
        funds = load_funds_from_excel()
        for fund in funds:
            var   = tk.BooleanVar(value=False)
            self.fund_vars[fund] = var
            frame = tk.Frame(self.fund_scroll.inner, bg=BG)
            frame.pack(fill="x", padx=4, pady=1)
            cb = tk.Checkbutton(frame, text=fund, variable=var,
                                 bg=BG, anchor="w", font=(FONT, 10),
                                 command=self._refresh_summary)
            cb.pack(fill="x")
            self.fund_scroll.hook(cb)
            self.fund_scroll.hook(frame)
            self._fund_rows.append((fund, frame, var))
        self._update_fund_count()

    # ── Search / filter ────────────────────────────────────────────────

    def _filter_funds(self):
        q = self.search_var.get().strip().lower()
        for fund, frame, _ in self._fund_rows:
            if q in fund.lower():
                frame.pack(fill="x", padx=4, pady=1)
            else:
                frame.pack_forget()
        self._update_fund_count()

    def _update_fund_count(self):
        q       = self.search_var.get().strip().lower()
        visible = sum(1 for f, _, _ in self._fund_rows if q in f.lower())
        self.fund_count_lbl.config(text=f"{visible} shown")

    def _toggle_visible_funds(self, state):
        q = self.search_var.get().strip().lower()
        for fund, _, var in self._fund_rows:
            if q in fund.lower():
                var.set(state)
        self._refresh_summary()

    def _toggle_all(self, var_dict, state):
        for var in var_dict.values():
            var.set(state)
        self._refresh_summary()

    def _select_hermes_funds(self):
        """Deselect all funds then select only those marked Hermes in the FOF file."""
        hermes = load_hermes_funds()
        if not hermes:
            messagebox.showwarning(
                "Hermes Funds",
                "Could not read the Hermes funds file.\n"
                f"Expected at:\n{HERMES_FUNDS_FILE}"
            )
            return
        for fund, var in self.fund_vars.items():
            var.set(fund in hermes)
        self._refresh_summary()

    def _refresh_summary(self):
        f_count = sum(1 for v in self.fund_vars.values() if v.get())
        d_count = sum(1 for v in self.date_vars.values() if v.get())
        if f_count == 0 and d_count == 0:
            self.summary_var.set("Select funds and dates below, then click Run.")
        else:
            total = f_count * d_count
            self.summary_var.set(
                f"{f_count} fund(s)  \u00d7  {d_count} date(s)  =  {total} report(s) queued"
            )

    # ── Output helpers ─────────────────────────────────────────────────

    def _append(self, text, tag=None):
        self.output.configure(state="normal")
        self.output.insert("end", text, tag or "")
        self.output.see("end")
        self.output.configure(state="disabled")

    def _clear(self):
        self.output.configure(state="normal")
        self.output.delete("1.0", "end")
        self.output.configure(state="disabled")

    def _log(self, msg, tag=None):
        self.after(0, self._append, msg + "\n", tag)

    # ── Start ──────────────────────────────────────────────────────────

    def _start_run(self):
        sel_funds = [f for f, v in self.fund_vars.items() if v.get()]
        sel_dates = [(lbl, val) for lbl, val in DATES if self.date_vars[val].get()]

        if not sel_funds:
            messagebox.showwarning("Nothing Selected",
                                   "Please select at least one fund.")
            return
        if not sel_dates:
            messagebox.showwarning("Nothing Selected",
                                   "Please select at least one date.")
            return

        pairs = [(fund, val, lbl)
                 for fund in sel_funds
                 for lbl, val in sel_dates]

        self._clear()
        self._append(
            f"Pre-Valuation Report Downloader\n"
            f"Funds: {', '.join(sel_funds)}\n"
            f"Dates: {', '.join(d[0] for d in sel_dates)}\n"
            f"Total: {len(pairs)} report(s)\n\n",
            "head"
        )

        self.run_btn.configure(state="disabled",
                                text=f"\u25b6  Running\u2026  0 / {len(pairs)}")
        self.status_var.set(f"Running \u2014 {len(pairs)} report(s) queued\u2026")

        threading.Thread(
            target=lambda: asyncio.run(self._run_automation(pairs)),
            daemon=True
        ).start()

    # ── Automation ─────────────────────────────────────────────────────

    async def _run_automation(self, pairs):
        ok = fail = 0

        def upd_btn(done):
            self.run_btn.configure(
                text=f"\u25b6  Running\u2026  {done} / {len(pairs)}")

        try:
            async with async_playwright() as p:
                browser = await p.chromium.launch(channel="msedge", headless=False)
                context = await browser.new_context(accept_downloads=True)
                page    = await context.new_page()

                self._log("Opening Edge \u2014 navigating to Hermes portal\u2026", "head")
                await page.goto(
                    "http://hermes-prd.gcmlp.com/Portal/Portal.aspx?redirect=true"
                )

                # Wait up to 5 minutes for the Reports nav link to appear —
                # this confirms SSO login is complete, no button click needed
                self._log("Please log in with your GCM credentials in the Edge window.")
                self._log("The script will continue automatically once you are logged in\u2026")
                await page.get_by_text("Reports", exact=True).first.wait_for(
                    timeout=300_000   # 5 minutes
                )
                self._log("Login detected. Starting downloads.\n", "ok")

                for i, (portfolio, run_date, date_label) in enumerate(pairs, 1):
                    self._log(f"[{i}/{len(pairs)}]  {portfolio}  \u2014  {date_label}", "head")
                    try:
                        # Navigate directly to the Pre-val Batch Reporting form.
                        # The URL was confirmed from earlier runs — this is simpler and
                        # more reliable than clicking through the hover menu.
                        FORM_URL = "http://hermes-prd.gcmlp.com/ReportLaunch/Index?reportPacketCode=Pre-val"
                        form_page = await context.new_page()
                        await form_page.goto(FORM_URL)
                        await form_page.wait_for_load_state("networkidle")
                        self._log(f"  Opened form: {form_page.url}")
                        await asyncio.sleep(1)

                        # Run Date — clear the field, type the date, press Tab to confirm
                        self._log(f"  Setting date to {run_date}\u2026")
                        df = page.locator("input").first   # fallback placeholder
                        for selector in [
                            "input[type='text']",
                            "input[type='date']",
                            "input[id*='Date']",
                            "input[name*='Date']",
                            "input[id*='date']",
                            "input[name*='date']",
                            "input",
                        ]:
                            loc = form_page.locator(selector).first
                            try:
                                await loc.wait_for(state="visible", timeout=5000)
                                df = loc
                                break
                            except Exception:
                                continue
                        await df.click(click_count=3)
                        await df.fill(run_date)
                        await df.press("Tab")   # confirm the date entry
                        await asyncio.sleep(0.5)

                        # Portfolio checkbox — use exact cell match to avoid
                        # e.g. "BUTTER" accidentally matching "BUTTERB"
                        self._log(f"  Selecting \u2018{portfolio}\u2019\u2026")
                        row = form_page.locator(f"tr:has(td:text-is('{portfolio}'))").first
                        await row.locator("input[type='checkbox']").first.check()
                        await asyncio.sleep(0.5)

                        # Process Reports button at the bottom of the page
                        self._log("  Clicking Process Reports\u2026")
                        await form_page.get_by_text("Process Reports", exact=True).first.click()
                        await form_page.wait_for_load_state("networkidle")
                        await asyncio.sleep(2)

                        # Batch Jobs Inquiry — wait for page to load
                        self._log("  Waiting for Batch Jobs Inquiry\u2026")
                        await form_page.wait_for_selector("text=Batch Jobs Inquiry",
                                                          timeout=60000)

                        # Build the job name pattern matching how the grid displays it.
                        # The grid strips leading zeros from month/day (e.g. 1/31/2026
                        # not 01/31/2026), so we reformat the date to match.
                        _dt = datetime.strptime(run_date, "%m/%d/%Y")
                        job_date = f"{_dt.month}/{_dt.day}/{_dt.year}"
                        job_pattern = f"{portfolio}-{job_date}-Pre-val"
                        # Scope to #JQGrid1 tbody — the grid sits inside an outer wrapper
                        # table, so plain "tbody tr" matches the wrapper row (containing
                        # the entire grid) rather than the actual data rows inside it.
                        row_sel = f"#JQGrid1 tbody tr:has-text('{job_pattern}')"

                        self._log("  Waiting for job to complete (checking every 15 seconds)\u2026")
                        import time as _time
                        deadline = _time.time() + 60    # 1-minute timeout

                        while True:
                            # Press the jqGrid refresh button (↺) in the bottom-left toolbar.
                            refresh_clicked = False
                            for refresh_sel in [
                                "#refresh_JQGrid1",
                                ".ui-icon-refresh",
                                "[title='Reload Grid']",
                                "[title='Refresh']",
                                ".ui-pg-button .ui-icon",
                            ]:
                                try:
                                    btn = form_page.locator(refresh_sel).first
                                    await btn.click(timeout=3000)
                                    refresh_clicked = True
                                    break
                                except Exception:
                                    continue
                            if not refresh_clicked:
                                await form_page.reload()
                            await asyncio.sleep(2)   # wait for grid to update

                            job_row = form_page.locator(row_sel).first
                            try:
                                row_text = await job_row.inner_text(timeout=5000)
                            except Exception:
                                row_text = ""

                            if "JOB COMPLETED" in row_text:
                                self._log("  Job complete!")
                                break

                            if _time.time() > deadline:
                                raise Exception(
                                    "Job timed out after 1 minute without completing."
                                )
                            self._log("  Still processing\u2026 waiting 15 seconds")
                            await asyncio.sleep(15)

                        # Download icon — click the File column (last td) of the job row.
                        # The portal opens the report in a new tab, so we capture that
                        # tab's URL then navigate to it to trigger the file download.
                        self._log("  Clicking download icon (File column)\u2026")
                        job_row = form_page.locator(row_sel).first
                        await job_row.scroll_into_view_if_needed()

                        # Scope to #JQGrid1 so we target the actual data row, not the
                        # outer wrapper row that contains the entire grid widget.
                        file_cell = form_page.locator(
                            f"#JQGrid1 tbody tr:has-text('{job_pattern}') td:last-child"
                        ).first

                        try:
                            cell_html = await file_cell.inner_html(timeout=3000)
                            self._log(f"  File cell HTML: {cell_html[:300]}")
                        except Exception:
                            pass

                        # The file icon requires a double-click and opens the report
                        # in a popup window. Capture the popup, get its URL, then
                        # navigate to that URL to trigger the file download.
                        # Double-click the file icon — a PDF viewer popup opens.
                        # Keep it open, then click Edge's download button (top-right)
                        # and capture the resulting file download.
                        async with context.expect_page(timeout=15000) as popup_info:
                            await file_cell.dblclick()
                        popup = await popup_info.value
                        await popup.wait_for_load_state("networkidle")
                        self._log(f"  Report URL: {popup.url}")

                        # Click Edge PDF viewer's download button and capture download
                        async with popup.expect_download(timeout=30000) as dl:
                            # Edge's built-in PDF viewer download button selectors
                            for btn_sel in [
                                "[aria-label='Download']",
                                "[title='Download']",
                                "#download",
                                "cr-icon-button[iron-icon='cr:file-download']",
                                "pierce/#download",
                            ]:
                                try:
                                    btn = popup.locator(btn_sel).first
                                    await btn.click(timeout=3000)
                                    break
                                except Exception:
                                    continue
                            else:
                                # Fallback: Ctrl+S triggers download in Edge PDF viewer
                                await popup.keyboard.press("Control+s")

                        download = await dl.value
                        await popup.close()

                        filename  = f"{portfolio} {fmt_filename_date(run_date)}.pdf"
                        save_path = os.path.join(SAVE_FOLDER, filename)
                        await download.save_as(save_path)

                        # Close the form tab (if a new one was opened) ready for next report
                        if form_page is not page:
                            await form_page.close()

                        self._log(f"  \u2714  Saved: {filename}\n", "ok")
                        ok += 1

                    except Exception as exc:
                        self._log(f"  \u2718  ERROR: {exc}\n", "error")
                        fail += 1

                    self.after(0, upd_btn, ok + fail)

                await browser.close()

        except Exception as exc:
            self._log(f"FATAL ERROR: {exc}", "error")

        finally:
            self._log(f"\u2014" * 40)
            if ok:
                self._log(f"\u2714  {ok} report(s) saved to:  {SAVE_FOLDER}", "ok")
            if fail:
                self._log(f"\u2718  {fail} report(s) failed.", "error")

            status = (f"Done \u2014 {ok} saved" + (f", {fail} failed" if fail else "") + ".")
            self.after(0, self.status_var.set, status)
            self.after(0, self.run_btn.configure,
                        {"state": "normal", "text": "\u25b6  Run Reports"})


# ── Entry point ────────────────────────────────────────────────────────

if __name__ == "__main__":
    App().mainloop()
