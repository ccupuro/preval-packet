@echo off
python "%~dp0report_downloader_ui.py"
if errorlevel 1 (
    echo.
    echo Something went wrong. See the message above.
    pause
)
