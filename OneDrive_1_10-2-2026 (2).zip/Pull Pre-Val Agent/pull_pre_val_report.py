import asyncio
import os
from datetime import datetime
from playwright.async_api import async_playwright

# ============================================================
# CONFIGURATION — Edit these two values before running
# ============================================================
RUN_DATE        = "12/31/2025"   # Month end date in MM/DD/YYYY format
PORTFOLIO_NAME  = "ASUTY"        # Exact portfolio name as it appears on screen
SAVE_FOLDER     = r"C:\Users\PMANN\OneDrive - GCM Grosvenor\Desktop\Claude\Month End Packet Review - pull pre-val"
# ============================================================


def format_date_for_filename(date_str):
    """Converts 12/31/2025 -> 12.31.2025 for the filename."""
    dt = datetime.strptime(date_str, "%m/%d/%Y")
    return dt.strftime("%m.%d.%Y")


async def main():
    async with async_playwright() as p:

        # --- Open Microsoft Edge (visible window) ---
        print("Opening Microsoft Edge...")
        browser = await p.chromium.launch(
            channel="msedge",
            headless=False          # Keep False — you need to see the browser
        )
        context = await browser.new_context(accept_downloads=True)
        page    = await context.new_page()

        # Step 1: Navigate to the portal
        print("Navigating to Hermes portal...")
        await page.goto("http://hermes-prd.gcmlp.com/Portal/Portal.aspx?redirect=true")

        # --- Pause for SSO login ---
        print("\n" + "="*60)
        print("  ACTION REQUIRED:")
        print("  Please log in with your GCM credentials in the Edge window.")
        print("  Once you can see the portal home screen, come back here")
        print("  and press ENTER to continue.")
        print("="*60)
        input()

        # Step 2: Click "Reports" in the top navigation panel
        print("\nStep 2: Clicking 'Reports' in the top panel...")
        await page.get_by_role("link", name="Reports").click()
        await page.wait_for_load_state("networkidle")
        await asyncio.sleep(1)

        # Step 3: Click "Pre Valuation Reports" in the left panel
        print("Step 3: Clicking 'Pre Valuation Reports' in the left panel...")
        await page.get_by_role("link", name="Pre Valuation Reports").click()
        await page.wait_for_load_state("networkidle")
        await asyncio.sleep(1)

        # Step 4: Set the Run Date
        print(f"Step 4: Setting Run Date to {RUN_DATE}...")
        # Looks for a date input field — we try common label patterns
        try:
            date_field = page.get_by_label("Run Date")
            await date_field.triple_click()   # Select all existing text first
            await date_field.fill(RUN_DATE)
        except Exception:
            # Fallback: find any text input and fill it
            date_field = page.locator("input[type='text']").first
            await date_field.triple_click()
            await date_field.fill(RUN_DATE)
        await asyncio.sleep(1)

        # Step 5: Check the box next to the portfolio name
        print(f"Step 5: Selecting portfolio '{PORTFOLIO_NAME}'...")
        # Find the table row that contains the portfolio name, then tick its checkbox
        portfolio_row = page.locator(f"tr:has-text('{PORTFOLIO_NAME}')").first
        run_checkbox  = portfolio_row.locator("input[type='checkbox']").first
        await run_checkbox.check()
        await asyncio.sleep(1)

        # Step 6: Click "Process Reports"
        print("Step 6: Clicking 'Process Reports'...")
        await page.get_by_role("button", name="Process Reports").click()
        await page.wait_for_load_state("networkidle")
        await asyncio.sleep(2)

        # Step 7: Wait for the "Batch Jobs Inquiry" screen, then wait 30 seconds
        print("Step 7: Waiting for Batch Jobs Inquiry screen...")
        await page.wait_for_selector("text=Batch Jobs Inquiry", timeout=60000)
        print("  Batch Jobs Inquiry loaded. Waiting 30 seconds for the report to generate...")
        for i in range(30, 0, -5):
            print(f"  {i} seconds remaining...")
            await asyncio.sleep(5)
        print("  Done waiting.")

        # Click the blue paper / download icon in the rightmost column
        print("  Clicking the download icon (blue paper)...")
        try:
            async with page.expect_download(timeout=30000) as download_info:
                # The icon is typically a small image/link in the last column of the first data row
                await page.locator("table tbody tr:first-child td:last-child a").click()
            download = await download_info.value
        except Exception:
            # Fallback: try any download link in the last column
            async with page.expect_download(timeout=30000) as download_info:
                await page.locator("td:last-child a").first.click()
            download = await download_info.value

        # Step 8: Save the PDF with the correct naming convention
        date_for_name = format_date_for_filename(RUN_DATE)
        filename      = f"{PORTFOLIO_NAME} {date_for_name}.pdf"
        save_path     = os.path.join(SAVE_FOLDER, filename)

        print(f"\nSaving report as: {filename}")
        await download.save_as(save_path)

        print("\n" + "="*60)
        print(f"  SUCCESS! Report saved to:")
        print(f"  {save_path}")
        print("="*60)

        await browser.close()


if __name__ == "__main__":
    asyncio.run(main())
